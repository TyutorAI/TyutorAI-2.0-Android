# TyutorAI 2.0 — secure Android WebView / beta source

**App:** TyutorAI 2.0 | **Test server:** `https://test.tyutorai.uz/` | **Android:** API 24+.

## What is included
- Works as a limited HTTPS-only browser for the existing PHP site; no user passwords, tokens, or API secrets are embedded in the APK.
- Allows internal pages only on `test.tyutorai.uz`, `tyutorai.uz` and `www.tyutorai.uz`; checks scheme, host, and port. External user-clicked HTTPS, mail and phone links open in other apps.
- JavaScript, DOM storage and first-party session cookies are enabled; third-party cookies are disabled.
- TLS errors are never ignored. Unsafe mixed content, cleartext traffic, file URLs, JS native bridge, and WebView remote debugging are disabled.
- Disables Android backup; in release builds blocks screenshots/screen recording (FLAG_SECURE). Debug builds allow screenshots for testing.
- Native file upload picker and authenticated HTTPS downloads via Android's system Save dialog, with a no-cookie-leak cross-domain redirect policy.
- Retry screen for connection/5xx errors; browser Back navigation; a stable Unicode Uzbek UI.

## Build using GitHub (free)
1. Upload **all** project files preserving folder layout, including the hidden `.github/workflows/build-apk.yml` file. Upload extracted files rather than only the ZIP.
2. In GitHub: Actions → **Build TyutorAI 2.0 APK** → Run workflow → green Run workflow.
3. Once the build is green, open the run, find Artifacts, download `TyutorAI-2.0-Android-debug-APK`.
4. Extract that artifact ZIP and install `app-debug.apk` on your Android device. This is a **debug-signed testing APK**, not a Play Store release.

If it is difficult to upload folders on a **phone**, use the separately provided `TyutorAI-Phone-OneFile-Workflow.yml` content. Paste it as `.github/workflows/build-apk.yml` in a private repository. It contains the entire Android project in a compressed source payload and builds it without any other project files.

## What is **not** verified
This container does not include Android SDK/Gradle and cannot download them, so the Android compiler and device tests were not run here. This is a source project and a build workflow, **not a finished verified APK**. Test site availability, all roles, login/logout, protected files, permission boundaries, responsive pages, and compatibility on several Android versions before production. No APK can guarantee 100% security; server-side controls are crucial.

## Production checklist
1. Fix and audit PHP/MySQL access control for all roles. Use secure sessions, CSRF protection and least-privilege permissions. An APK cannot fix server vulnerabilities.
2. Configure correct SSL/TLS certificates and HTTPS redirects for all three allowed domains.
3. Turn on device-level protections and review site CSP/XSS vulnerabilities.
4. Build a signed **release** APK/AAB in a secure environment (do not commit `.jks` / signing passwords to GitHub).
5. Replace `MAIN_URL` in `app/src/main/java/uz/tyutorai/mobile/MainActivity.java` with `https://tyutorai.uz/` **only when the production server passes testing**.
6. Verify functional file downloads, including PDF and DOCX, and upload forms for each role. OAuth/popups, JS blob: downloads, QR scanning, camera/microphone permissions and push notifications require further integration.

## Phone-only workflow
The standalone `TyutorAI-Phone-OneFile-Workflow.yml` file is distributed separately from this ZIP. Paste its **entire** contents into the GitHub workflow path `.github/workflows/build-apk.yml` using the GitHub web editor. It contains the full application source and can build from an otherwise empty repository.
