# There is no addJavascriptInterface(), so no JS bridge classes need to be kept.
# Android retains the launcher Activity declared in the manifest.
