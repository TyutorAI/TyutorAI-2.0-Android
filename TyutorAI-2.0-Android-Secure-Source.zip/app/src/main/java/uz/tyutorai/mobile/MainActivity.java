package uz.tyutorai.mobile;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.view.WindowInsets;
import android.graphics.Insets;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final String MAIN_URL = "https://test.tyutorai.uz/";
    private static final int REQ_FILE = 110;
    private static final int REQ_SAVE = 111;
    private static final int MAX_REDIRECTS = 4;

    private final ExecutorService downloads = Executors.newSingleThreadExecutor();
    private WebView browser;
    private ProgressBar loading;
    private View errorPanel;
    private android.webkit.ValueCallback<Uri[]> fileCallback;
    private String pendingDownloadUrl;
    private String pendingDownloadAgent;

    private static boolean isAllowed(Uri uri) {
        if (uri == null || !"https".equalsIgnoreCase(uri.getScheme())) return false;
        if (uri.getUserInfo() != null) return false;
        int port = uri.getPort();
        if (port != -1 && port != 443) return false;
        String host = uri.getHost();
        if (host == null) return false;
        switch (host.toLowerCase(Locale.ROOT)) {
            case "test.tyutorai.uz":
            case "tyutorai.uz":
            case "www.tyutorai.uz":
                return true;
            default:
                return false;
        }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!BuildConfig.DEBUG) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        }
        WebView.setWebContentsDebuggingEnabled(false);
        setContentView(R.layout.activity_main);
        // Android 15+ draws behind system bars; keep important controls visible.
        if (Build.VERSION.SDK_INT >= 35) {
            View content = findViewById(android.R.id.content);
            content.setOnApplyWindowInsetsListener((v, insets) -> {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return insets;
            });
        }
        browser = findViewById(R.id.webview);
        loading = findViewById(R.id.progress);
        errorPanel = findViewById(R.id.error_panel);
        Button retry = findViewById(R.id.retry_button);
        retry.setOnClickListener(v -> {
            hideError();
            String url = browser.getUrl();
            browser.loadUrl(isAllowed(Uri.parse(url == null ? "" : url)) ? url : MAIN_URL);
        });

        WebSettings settings = browser.getSettings();
        settings.setJavaScriptEnabled(true); // The university portal requires JS.
        settings.setDomStorageEnabled(true); // Language and theme depend on DOM storage.
        settings.setAllowFileAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        if (Build.VERSION.SDK_INT >= 26) settings.setSafeBrowsingEnabled(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(browser, false);

        browser.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (!request.isForMainFrame()) return false;
                Uri uri = request.getUrl();
                if (isAllowed(uri)) return false;
                if (request.hasGesture()) openExternal(uri);
                return true; // Never load an untrusted top-level page inside WebView.
            }

            @Override public void onReceivedSslError(WebView view,
                                                       SslErrorHandler handler, SslError error) {
                handler.cancel(); // Never bypass TLS verification.
                showError();
            }

            @Override public void onReceivedError(WebView view, WebResourceRequest request,
                                                   WebResourceError error) {
                if (request.isForMainFrame()) showError();
            }

            @Override public void onReceivedHttpError(WebView view, WebResourceRequest request,
                                                       WebResourceResponse response) {
                if (request.isForMainFrame() && response.getStatusCode() >= 500) showError();
            }

            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap icon) {
                hideError();
                loading.setVisibility(View.VISIBLE);
            }

            @Override public void onPageFinished(WebView view, String url) {
                loading.setVisibility(View.GONE);
                CookieManager.getInstance().flush();
            }

            @Override public boolean onRenderProcessGone(WebView view,
                             android.webkit.RenderProcessGoneDetail detail) {
                // Android requires removal and destruction of the dead WebView.
                if (view.getParent() instanceof ViewGroup) {
                    ((ViewGroup) view.getParent()).removeView(view);
                }
                view.destroy();
                browser = null;
                recreate();
                return true;
            }
        });

        browser.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int progress) {
                loading.setVisibility(progress < 100 ? View.VISIBLE : View.GONE);
            }

            @Override public boolean onShowFileChooser(WebView view,
                    android.webkit.ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    // Only a user-selected file is returned. The app has no storage permission.
                    startActivityForResult(intent, REQ_FILE);
                    return true;
                } catch (ActivityNotFoundException ex) {
                    fileCallback = null;
                    toast("Fayl tanlash oynasi mavjud emas");
                    return false;
                }
            }

            @Override public void onPermissionRequest(android.webkit.PermissionRequest request) {
                // The APK does not request camera/microphone permissions.
                request.deny();
            }
        });

        browser.setDownloadListener((url, userAgent, contentDisposition, mime, length) -> {
            Uri uri = Uri.parse(url);
            if (!isAllowed(uri)) {
                toast("Yuklab olish faqat ishonchli HTTPS manzildan ruxsat etilgan");
                return;
            }
            pendingDownloadUrl = url;
            pendingDownloadAgent = userAgent;
            String filename = android.webkit.URLUtil.guessFileName(url, contentDisposition, mime);
            if (filename == null || filename.trim().isEmpty()) filename = "tyutorai-file";
            Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            save.addCategory(Intent.CATEGORY_OPENABLE);
            save.setType(mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
            save.putExtra(Intent.EXTRA_TITLE, filename);
            try {
                startActivityForResult(save, REQ_SAVE);
            } catch (ActivityNotFoundException ex) {
                pendingDownloadUrl = null;
                toast("Faylni saqlash oynasi mavjud emas");
            }
        });

        if (savedInstanceState != null && browser.restoreState(savedInstanceState) != null) {
            String restored = browser.getUrl();
            if (restored != null && !isAllowed(Uri.parse(restored))) browser.loadUrl(MAIN_URL);
        } else {
            browser.loadUrl(MAIN_URL);
        }
    }

    private void openExternal(Uri uri) {
        if (uri == null) return;
        String scheme = uri.getScheme();
        if (scheme == null || !("https".equalsIgnoreCase(scheme) ||
                "mailto".equalsIgnoreCase(scheme) || "tel".equalsIgnoreCase(scheme))) {
            toast("Ushbu havola xavfsizlik sababli bloklandi");
            return;
        }
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);
        } catch (ActivityNotFoundException ex) {
            toast("Havolani ochadigan ilova topilmadi");
        }
    }

    private void showError() {
        if (browser != null) browser.setVisibility(View.INVISIBLE);
        if (errorPanel != null) errorPanel.setVisibility(View.VISIBLE);
        if (loading != null) loading.setVisibility(View.GONE);
    }

    private void hideError() {
        if (browser != null) browser.setVisibility(View.VISIBLE);
        if (errorPanel != null) errorPanel.setVisibility(View.GONE);
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE) {
            if (fileCallback != null) {
                fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                fileCallback = null;
            }
        } else if (requestCode == REQ_SAVE) {
            final String downloadUrl = pendingDownloadUrl;
            final String userAgent = pendingDownloadAgent;
            pendingDownloadUrl = null;
            pendingDownloadAgent = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null &&
                    downloadUrl != null) {
                Uri destination = data.getData();
                downloads.execute(() -> saveAuthenticatedDownload(downloadUrl, userAgent, destination));
            }
        }
    }

    private void saveAuthenticatedDownload(String urlText, String userAgent, Uri destination) {
        HttpURLConnection conn = null;
        try {
            String current = urlText;
            String cookie = CookieManager.getInstance().getCookie(current);
            for (int hop = 0; hop <= MAX_REDIRECTS; hop++) {
                Uri target = Uri.parse(current);
                if (!isAllowed(target)) throw new SecurityException("Untrusted redirect");
                conn = (HttpURLConnection) new URL(current).openConnection();
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(30000);
                conn.setInstanceFollowRedirects(false); // Keep session cookies off other domains.
                conn.setRequestMethod("GET");
                if (userAgent != null && !userAgent.isEmpty()) {
                    conn.setRequestProperty("User-Agent", userAgent);
                }
                if (cookie != null && !cookie.isEmpty()) {
                    conn.setRequestProperty("Cookie", cookie);
                }
                int status = conn.getResponseCode();
                if (status == 301 || status == 302 || status == 303 ||
                        status == 307 || status == 308) {
                    String location = conn.getHeaderField("Location");
                    if (location == null) throw new java.io.IOException("No redirect location");
                    URL resolved = new URL(new URL(current), location);
                    String next = resolved.toExternalForm();
                    if (!isAllowed(Uri.parse(next))) throw new SecurityException("External redirect");
                    conn.disconnect();
                    conn = null;
                    current = next;
                    cookie = CookieManager.getInstance().getCookie(current);
                    continue;
                }
                if (status != 200) throw new java.io.IOException("HTTP status " + status);
                try (InputStream in = conn.getInputStream();
                     OutputStream out = getContentResolver().openOutputStream(destination, "w")) {
                    if (out == null) throw new java.io.IOException("Cannot open output file");
                    byte[] buffer = new byte[16384];
                    int bytes;
                    while ((bytes = in.read(buffer)) != -1) out.write(buffer, 0, bytes);
                }
                runOnUiThread(() -> toast("Fayl saqlandi"));
                return;
            }
            throw new java.io.IOException("Too many redirects");
        } catch (Exception err) {
            runOnUiThread(() -> toast("Fayl saqlanmadi. Havola yoki sessiyani tekshiring"));
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    @Override public void onBackPressed() {
        if (browser != null && browser.canGoBack()) browser.goBack();
        else super.onBackPressed();
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        if (browser != null) browser.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override protected void onDestroy() {
        if (fileCallback != null) {
            fileCallback.onReceiveValue(null);
            fileCallback = null;
        }
        downloads.shutdownNow();
        if (browser != null) {
            browser.stopLoading();
            browser.destroy();
            browser = null;
        }
        super.onDestroy();
    }
}
